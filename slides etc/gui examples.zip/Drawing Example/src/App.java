import javax.swing.JFrame;

public class App {
    public static void main(String[] args) throws Exception {
        JFrame f = new JFrame();
        
        f.add(new MyPanel());
        
        f.pack();
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}