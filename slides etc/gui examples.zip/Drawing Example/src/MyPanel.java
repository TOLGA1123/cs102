import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import javax.swing.JPanel;

public class MyPanel extends JPanel {

    public MyPanel() {
        setPreferredSize(new Dimension(500, 500));
        setBackground(Color.YELLOW);
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        g.drawString("Hello, world.", 50, 200);
        g.drawRect(100, 200, 100, 200);
        g.drawOval(100, 200, 100, 200);
    }
}