import javax.swing.JFrame;


public class HappyFaceViewer {
    
    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setTitle( "Smile!" );
        
        // frame.add( new HappyFacePanel() );  
        frame.add(new HappyFaceColorPanel());           

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        frame.pack();
    }
}
