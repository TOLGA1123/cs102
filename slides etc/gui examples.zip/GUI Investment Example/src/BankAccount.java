public class BankAccount {
    public static final double INTEREST_RATE = 0.05;

    private double balance;

    public BankAccount( double balance ) {
        this.balance = balance;
    }

    public double getBalance() {
        return balance;
    }

    public void addInterest() {
        balance += balance * INTEREST_RATE;
    }

    public void addInterest( double rate ) {
        balance += balance * rate / 100;
    }
}
