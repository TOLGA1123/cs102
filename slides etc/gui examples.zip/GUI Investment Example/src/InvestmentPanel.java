import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class InvestmentPanel extends JPanel {
    JButton button;
    JLabel rateLabel;
    JLabel resultLabel;
    JTextField interestField;
    JTextArea textArea;
    JScrollPane scrollPane;
    BankAccount account;

    public InvestmentPanel() {
        System.out.println( "in Simple Panel constructor..." );
        account = new BankAccount( 10 );

        setPreferredSize(new Dimension(400, 500));
        
        button = new JButton( "Add Interest") ;
        button.addActionListener( new AddInterestListener() );
        /* button.addActionListener( new ActionListener( ) {
            public void actionPerformed( ActionEvent event ) {
                account.addInterest();
                label.setText( "BALANCE: " + account.getBalance() );
            }
        } ); */
        rateLabel = new JLabel( "Interest Rate: " );
        resultLabel = new JLabel( "Balance: " + account.getBalance() ) ;
        textArea = new JTextArea( 10, 30 );
        textArea.setEditable(false);
        textArea.setText("Balance: ");
        scrollPane = new JScrollPane(textArea);
        interestField = new JTextField( 10 ); 

        add( rateLabel );  
        add(interestField);
        add( button );
        add(resultLabel);        
        // add( textArea );       
        add(scrollPane);
    }

    /** 
     * An action listener that prints a message
     */
    public class AddInterestListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent arg0) {
            System.out.println( "Adding interest..." );
            double interest = Double.parseDouble(interestField.getText());
            // account.addInterest();
            account.addInterest(interest);
            textArea.append( account.getBalance() + "\n" );     
            resultLabel.setText( "Balance: " + account.getBalance() );       

        }
        
    }

}
