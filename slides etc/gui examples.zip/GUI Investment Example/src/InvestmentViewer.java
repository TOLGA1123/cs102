import javax.swing.JFrame;

public class InvestmentViewer {
    public static void main(String[] args) throws Exception {
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);      
        frame.setTitle("Investment App");
        frame.add( new InvestmentPanel() );        
        frame.pack();
    }
}
