import java.awt.Dimension;

import javax.swing.JFrame;

public class App {
    public static void main(String[] args) throws Exception {
        JFrame frame = new JFrame();

        frame.add(new MyPanel());

        frame.setTitle("Hello CS102");
        // frame.setPreferredSize(new Dimension(300, 400));
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
        frame.setVisible(true);
    }
}
