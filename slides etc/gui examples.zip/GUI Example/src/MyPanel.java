import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class MyPanel extends JPanel  {
    private JButton button1;
    private JButton button2;
    private JLabel label1;
    private JLabel label2;

    public MyPanel() {
        setPreferredSize(new Dimension(300, 400));

        button1 = new JButton("Click me!");
        // button1.addActionListener(new ClickListener());
        button1.addActionListener(new InnerClickListener());
        button2 = new JButton("Click me too!");
        button2.addActionListener(new ActionListener() { @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("I was clicked too.");
            
            } 
        }
        );
        
        label1 = new JLabel("Hello again!");
        ImageIcon icon = new ImageIcon("tux.png");
        label2 = new JLabel(icon);

        add(button1);
        add(button2);
        add(label1);
        add(label2);
    }

    private class InnerClickListener implements ActionListener {
        private int count;

        public InnerClickListener() {
            count = 0;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            String message;
            count++;
            message = "I was clicked " + count + " times";
            System.out.println(message);
            label1.setText(message);
        }
    }
}
