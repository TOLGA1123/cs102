package guiCount;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

public class CounterControls extends JPanel
{
	   private CounterPanel count;
	   private JButton undoButton, redoButton, resetButton;

	   //-----------------------------------------------------------------
	   //  Sets up the control panel.
	   //-----------------------------------------------------------------
	   public CounterControls (CounterPanel countPanel)
	   {
	      count = countPanel;

	      undoButton = new JButton ("Undo");
	      undoButton.addActionListener (new UndoListener());

	      redoButton = new JButton ("Redo");
	      redoButton.addActionListener (new RedoListener());
	      
	      resetButton = new JButton ("Reset");
	      resetButton.addActionListener (new ResetListener());

	      setBackground (Color.black);
	      add (undoButton);
	      add (redoButton);
	      add (resetButton);
	   }

	   //*****************************************************************
	   //  Represents the listener for the Undo button.
	   //*****************************************************************
	   private class UndoListener implements ActionListener
	   {
	      public void actionPerformed (ActionEvent event)
	      {
	         count.undo();
	         count.repaint();
	      }
	   }

	   //*****************************************************************
	   //  Represents the listener for the Redo button.
	   //*****************************************************************
	   private class RedoListener implements ActionListener
	   {
	      public void actionPerformed (ActionEvent event)
	      {
	         count.redo();
	         count.repaint();
	      }
	   }
	   
	   //*****************************************************************
	   //  Represents the listener for the Reset button.
	   //*****************************************************************
	   private class ResetListener implements ActionListener
	   {
	      public void actionPerformed (ActionEvent event)
	      {
	         count.reset();
	         count.repaint();
	      }
	   }

}
