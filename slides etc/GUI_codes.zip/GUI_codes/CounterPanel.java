package guiCount;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.DecimalFormat;
import java.util.ArrayList;

import javax.swing.JPanel;

//import CounterPanel.CounterListener;

public class CounterPanel extends JPanel
{
	   private final int WIDTH=300, HEIGHT=300;
	   private final int GAP=15;
	   private ArrayList<Point> pointList;
	   private ArrayList<Double> lengthList;

	   private Point current;
	   private Point next;
	   private Point temp;
	   private double length;
	   private Double templength;

	   //-----------------------------------------------------------------
	   //  Constructor: Sets up the panel and necessary data.
	   //-----------------------------------------------------------------
	   public CounterPanel()
	   {
		   pointList = new ArrayList<Point>();
		   lengthList = new ArrayList<Double>();
		   addMouseListener (new CounterListener());

		   setPreferredSize (new Dimension(WIDTH, HEIGHT));
		   setBackground (Color.yellow);
	   }

	   //-----------------------------------------------------------------
	   //  Draws a line from the mouse pointer to the center point of
	   //  the applet and displays the distance.
	   //-----------------------------------------------------------------
	   public void paintComponent (Graphics page)
	   {
	      super.paintComponent (page);
	      
	      if (pointList.size() >= 1){
	    	  	current = pointList.get(0);
	    	  	page.drawOval (current.x-3, current.y-3, 6, 6);
	      }

	      if (pointList.size() >= 2)
	      {
	    	  	for (int i = 0;i<pointList.size()-1;i++){
	    	  			current = pointList.get(i);
	    	  			next = pointList.get(i+1);
		          	page.drawLine (current.x, current.y, next.x, next.y);
		          	
		       		page.drawString ("Distance" + i + ": " + lengthList.get(i), 5, 15+(i*GAP));
		          	}
	      }
	      
	      
	   }
	   
	   public void undo ()
	   {
		   temp = pointList.get(pointList.size()-1);
		   pointList.remove(pointList.size()-1);
		   
		   templength = lengthList.get(lengthList.size()-1);
		   lengthList.remove(lengthList.size()-1);
	   }
	   
	   public void redo ()
	   {
		   pointList.add(temp);
		   lengthList.add(templength);
	   }
	   
	   public void reset ()
	   {
		   pointList.clear();
		   lengthList.clear();
	   }

	   //*****************************************************************
	   //  Represents the listener for mouse events. Demonstrates the
	   //  ability to extend an adaptor class.
	   //*****************************************************************
	   private class CounterListener extends MouseAdapter
	   {
	      //--------------------------------------------------------------
	      //  Computes the distance from the mouse pointer to the center
	      //  point of the applet.
	      //--------------------------------------------------------------
	      public void mouseClicked (MouseEvent event)
	      {
	    	  	pointList.add(event.getPoint());
	    	  	if (pointList.size() >= 2){
	    	  		Point first = pointList.get(pointList.size()-1);
	    	  		Point second = pointList.get(pointList.size()-2);
	    	  		Double newlength = Math.sqrt(Math.pow((first.x-second.x), 2) + Math.pow((first.y-second.y), 2));
	    	  		lengthList.add(newlength);
	    	  	}
	    	  	
	         repaint();
	      }
	   }
}
