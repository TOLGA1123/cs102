public class Factorial {
    public static void main(String[] args) {
        int x = 5;   // try 10, 20, 30, 40, 31, 32, 33, 34, 1000, 10000, 20000
        System.out.println(x + "! = " + factorial(x));
    }

     // compute n!
    // n! = n x (n-1)!
    // 0! = 1
    public static int factorial(int n) {
        if (n == 0)
            return 1;    // base case (known instance)
        return n * factorial(n-1);
    }
}
