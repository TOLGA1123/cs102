public class Strings {
    
    public static void main(String[] args) {
        String s = "Java";
        System.out.println("len of " + s + " is " + len(s));

        String[] arr = {"madam", "eye", "level", "racecar", "java", "face", "noon", "noun"};
        for (String str : arr)
            System.out.println("Is " + str + " palindrome?" + isPalindrome(str));

        display(s);
        System.out.println("***");
        display2(s);
    }

    // compute length of a string, len(s)
    // len(s) = 1 + len(s.substring(1))
    // len("") = 0
    public static int len(String s) {
        if (s.isEmpty())
            return 0;
        // System.out.println(s);
        return 1 + len(s.substring(1));
    }

     // is string a Palindrome?
     public static boolean isPalindrome(String s) {
        if (s.length() <= 1)  // base case: empty or 1-char string
            return true;
        else if (s.charAt(0) != s.charAt(s.length() - 1))
            return false;
        else
            return isPalindrome(s.substring(1, s.length()-1));
    }

    // print text forward recursively -- version 1
    public static void display(String s) {
        if (s.length() > 0) {
            display(s.substring(0, s.length() - 1));
            System.out.println(s.charAt(s.length()-1));
        }
    }

     // print text forward recursively -- version 2
     public static void display2(String s) {
        if (s.length() > 0) {
            System.out.println(s.charAt(0));
            display2(s.substring(1));            
        }
    }

    // Exerice: print text reverse recursively 

}
