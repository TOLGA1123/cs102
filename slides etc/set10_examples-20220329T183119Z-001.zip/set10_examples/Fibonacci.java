public class Fibonacci {
    
    public static void main(String[] args) {
        for (int i = 0; i < 100; i += 5) {
            System.out.println("fiboIterative(" + i + ") = " + fiboIterative(i));
            System.out.println("fiboRecursive(" + i + ") = " + fiboRecursive(i));            
        }
    }

    // calculate fibonacci number
    // fibo(n) = fibo(n-1) + fibo(n-2)
    // fibo(1) = 1, fibo(2) = 1 
    public static long fiboRecursive(int n) {
        if (n <= 2)
            return 1;
        return fiboRecursive(n-1) + fiboRecursive(n-2);
    }

    // calculate fibonacci number iteratively
    public static long fiboIterative(int n) {  
        if (n <= 2) 
            return 1; 
        else {
            long previous = 1;
            long current = 1;
            long next = 1;
            for (int i = 3; i <= n; i++) {  
                next = previous + current;
                previous = current;
                current = next;
            }
            return next;
        }
    }

}
