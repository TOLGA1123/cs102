import java.util.ArrayList;

public class Permuation {
    
    public static void main(String[] args) {
        // permute("abcd");
        ArrayList<String> r = permutation("abc", "");
        System.out.println(r);
    }
    // generate all permutations 
    public static void permute(String s) {
        permute(s, "");
    }

    // generate all permutations recursively
    // private recursive helper
    private static void permute(String s, String prefix) {
        if (s.length() == 0)
            System.out.println(prefix);
        else {
            for (int i = 0; i < s.length(); i++) {
                // add ith char to prefix, and 
                // exclude it from next string to be permuted
                permute(s.substring(0, i) + s.substring(i + 1), 
                        prefix + s.charAt(i));
            }
        }
    }

    // generate all permutations recursively
    // private recursive helper
    private static ArrayList<String> permutation(String s, String prefix) {
        ArrayList<String> list = new ArrayList<>();
        if (s.length() == 0)
            list.add(prefix);
        else {
            for (int i = 0; i < s.length(); i++) {
                // add ith char to prefix, and 
                // exclude it from next string to be permuted
                ArrayList<String> result = permutation(s.substring(0, i) + s.substring(i + 1), 
                        prefix + s.charAt(i));
                        for (String string : result) 
                            list.add(string);                    
            }
        }
        return list;
    }

}
