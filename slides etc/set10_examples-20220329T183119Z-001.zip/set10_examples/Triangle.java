public class Triangle {
    
    public static void main(String[] args) {
        int x = 5;
        
        System.out.println("Triangle of " + x + " lines");
        triangle(x);       

        System.out.println("Inverted Triangle of " + x + " lines");
        inverted(x);   
        
        System.out.println("Justified Triangle of " + x + " lines");
        justified(x);    

        System.out.println("triangle number for " + x + ": " + triangleArea(x) );
    }

    /* print a triangle shape

    *
    **
    ***
    ****
    
    */
    public static void triangle(int lineCount) {
        if (lineCount != 0) {
            triangle(lineCount - 1);
            for (int i = 0; i < lineCount; i++) {
                System.out.print("*");
            }                
            System.out.println();
        }
    }

    /* print an inverted triangle shape 

    ****
    ***
    **
    *

    */
    public static void inverted(int lineCount) {
        if (lineCount != 0) {
            for (int i = 0; i < lineCount; i++) {
                System.out.print("*");
            }                
            System.out.println();
            inverted(lineCount - 1);           
        }
    }

    /* print a triangle shape justified

    ****
     ***
      **
       *

    */
    // helper
    public static void justified(int lineCount, int totalLineCount) {
        if (lineCount != 0) {
            for (int i = 0; i < totalLineCount - lineCount; i++) {
                System.out.print(" ");
            }   
            for (int i = 0; i < lineCount; i++) {
                System.out.print("*");
            }                
            System.out.println();
            justified(lineCount - 1, totalLineCount);           
        }
    }
    public static void justified(int lineCount) {
        justified(lineCount, lineCount);
    }

    /* compute triangle area assuming each * area is 1 */
    public static int triangleArea(int lineCount) {
        if (lineCount == 0)
            return 0;

        return lineCount + triangleArea(lineCount - 1);
    }

}
