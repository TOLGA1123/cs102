public interface Difficulty {
    

    void setDifficulty(int difficulty); // easy medium hard 1 2 3
    int getDifficulty();
}
