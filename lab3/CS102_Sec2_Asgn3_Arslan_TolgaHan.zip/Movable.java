import java.awt.*;
public interface Movable {
    
    void move(); //can only move in -y direction
    
    Point getLocation();
}
