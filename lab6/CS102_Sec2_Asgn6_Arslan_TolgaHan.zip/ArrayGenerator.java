public interface ArrayGenerator {

    // a method to generate an array of size n in range [1,n]
    public Integer[] generate(int n);
}