public class Hangman{
    //properties
    private StringBuffer secretWord;
    private StringBuffer knownSoFar;
    private StringBuffer usedLetters;
    private StringBuffer allLetters;
    private int numOfIncorrectTries;
    private int maxAllowedIncorrectTries;
    //constructor
    public Hangman(){

    }
    //getters and setters
    public StringBuffer getSecretWord(){
        return secretWord;
    }
    public StringBuffer getKnownSoFar(){
        return knownSoFar;
    }
    public StringBuffer getUsedLetters(){
        return usedLetters;
    }
    public StringBuffer getAllLetters(){
        return allLetters;
    }
    public int getNumOfIncorrectTries(){
        return numOfIncorrectTries;
    }
    public int getMaxAllowedIncorrectTries(){
        return maxAllowedIncorrectTries;
    }
    public void setSecretWord(StringBuffer secretWord){
        this.secretWord = secretWord;
    }
    public void setKnownSoFar(StringBuffer knownSoFar){
        this.knownSoFar = knownSoFar;
    }
    public void setAllLetters(StringBuffer allLetters){
        this.allLetters = allLetters;
    }
    public void setUsedLetters(StringBuffer usedLetters){
        this.usedLetters = usedLetters;
    }
    public void setNumberOfIncorrectTries(int numberOfIncorrectTries){
        this.numOfIncorrectTries = numberOfIncorrectTries;
    }
    public void setMaxAllowedIncorrectTries(int maxAllowedIncorrectTries){
        this.maxAllowedIncorrectTries = maxAllowedIncorrectTries;
    }
    //other methods
    public String chooseSecretWord(){

    }
    public void tryThis(){

    }
    public boolean hasLost(){
        return numOfIncorrectTries == maxAllowedIncorrectTries;
    }
    public boolean isGameOver(){
        if(hasLost() == true || knownSoFar.equals(secretWord)){
            return true;
        }
        else{
            return false;
        }
    }
}