package hw;

public class Hangman {
    public Hangman(){
        maxAllowedIncorrectTries = 6;
        allLetters = getAllLetters();
        secretWord = chooseSecretWord();
    }
}
