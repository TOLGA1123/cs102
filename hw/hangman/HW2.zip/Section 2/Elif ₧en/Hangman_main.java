import java.util.Scanner;
public class Hangman_main {
        public static void main(String[] args) {
            /* in this project we wrote a main method for hangman game. We have created a hangman
            object and let the user play with it. 
            Authors: Bartu Mumcu, Yassin Younis, Elif Şen */
        String guessedletter;
        Scanner in = new Scanner(System.in);
        Hangman hangman = new Hangman();

        while(!isGameOver()){  
            System.out.println("Remaining attempts:"+ hangman.getMaxAllowedIncorrectTries()- hangman.getNumOfIncorectTries());
            System.out.println("Used letters:" + hangman.getUsedLetters());
            System.out.print("Guess a letter:");
            guessedletter= in.next();
            hangman.tryThis(guessedletter);      // We assume it passes the guessed letter to getKnownSoFar(). So getKnownSoFar() can work.    
            System.out.println("The word so far:"+ (hangman.getKnownSoFar());   
            
        }
        if(hangman.hasLost()){
            System.out.println("SORRY! YOU HAVE LOST!");
        }
        else {
            System.out.println("YOU WIN!");
        }

    }
    
}
}
