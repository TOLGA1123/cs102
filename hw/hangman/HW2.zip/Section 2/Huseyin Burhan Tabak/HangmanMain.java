import java.util.Scanner;

/*
 * Authors:
 * Huseyin Burhan Tabak - 22102516
 * Onur Taninmis - 22003312
 * Sara Zebardast - 22101014
 */
public class HangmanMain {

    // The main method plays the game by creating an instance of the Hangman class and using its methods.
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        Hangman hangman = new Hangman();

        // Greeting the user.
        System.out.println("Welcome to the hangman game. Can you guess the secret word?");

        // The game is played in this loop.
        // In every iteration, the user is asked to input a letter and the information is updated.
        // The loop ends if the isGameOver method returns true at the end of an iteration.
        while (!hangman.isGameOver()) {

            // Informing the user about the partially-guessed word and the number of wrong attempts left.
            System.out.println("The secret word is: " + hangman.getKnownSoFar());
            int wrongAttemptsLeft = hangman.getMaxAllowedIncorrectTries() - hangman.getNumOfIncorrectTries();
            System.out.println("You have " + wrongAttemptsLeft + " wrong attempts left.");

            // Asking until the user inputs a letter.
            // Accepting the first character as the guess for inputs with length greater than 1.
            System.out.print("Guess a letter: ");
            String guess = in.nextLine();
            while (guess.length() == 0 || !Character.isLetter(guess.charAt(0))) {
                System.out.print("You didn't input a letter. Try again: ");
                guess = in.nextLine();
            }
            char guessedLetter = guess.charAt(0);

            //Now we have a valid guess in terms of being a letter. Checking if the guess is a correct guess.
            int numOfOccurrences = hangman.tryThis(guessedLetter);
            if (numOfOccurrences == 0) {
                System.out.println("Wrong guess :(");
            } else {
                System.out.println("Nice! There are " + numOfOccurrences + guessedLetter + "'s in the secret word.");
            }
            System.out.println("Used letters are: " + hangman.getUsedLetters());
        }

        //Game is over when the loop ends. Informing the user if they have won or lost.
        System.out.println("Game over!");
        if (hangman.hasLost()) {
            System.out.println("Bad luck :( You lost.");
        } else {
            System.out.println("Congratulations! You won!");
        }
        in.close();
    }
}