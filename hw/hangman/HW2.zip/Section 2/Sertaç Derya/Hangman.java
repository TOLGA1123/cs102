//Sertaç Derya 22003208, Umut Arda Filiz 22102323, Barış Sunar 22003479
public class Hangman 
{
    private StringBuffer secretWord;
    private StringBuffer allLetters;
    private StringBuffer usedLetters;
    private int numberOfIncorrectTries;
    private final int maxAllowedIncorrectTries = 6;
    private StringBuffer knownSoFar;

    public Hangman()   
    {
        this.allLetters = new StringBuffer("abcdefghijklmnoqprstuvwxyz");
        this.usedLetters = new StringBuffer(26);
        this.numberOfIncorrectTries = 0;
        this.secretWord = chooseSecretWord(); // method that will be implemented by other groups
        this.knownSoFar = new StringBuffer(20);
        for(int i = 0; i < this.secretWord.length(); i++)
        {
            this.knownSoFar.append("_");
        }
    } 
}
