public class Hangman
{
    private StringBuffer secretWord, knownSoFar, allLetters, usedLetters;
    private int numIncorrectTries;

    public Hangman(){}

    public void tryThis(){}
    public void chooseSecretWord(){}
    public StringBuffer getSecretWord()
    {
        return secretWord;
    }
    public StringBuffer getKnownSoFar()
    {
        return knownSoFar;
    }
    public StringBuffer getUsedLetters()
    {
        return usedLetters;
    }
    public StringBuffer getAllLetters()
    {
        return allLetters;
    }
    public int getIncorrectTries()
    {
        return numIncorrectTries;
    }
}