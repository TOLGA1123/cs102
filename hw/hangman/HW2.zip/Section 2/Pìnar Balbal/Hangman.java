public class Hangman{
    // Properties
    private StringBuffer secretWord;
    private StringBuffer knownSoFar;
    private StringBuffer usedLetters;
    private StringBuffer allLetters;
    private int numIncorrectTries;

    public Hangman(){

    }

    public StringBuffer getSecretWord(){
        return secretWord;
    }
    public StringBuffer getKnownSoFar(){
        return knownSoFar;
    }
    public StringBuffer getUsedLetters(){
        return usedLetters;
    }
    public StringBuffer getAllLetters(){
        return allLetters;
    }
    public int getNumIncorectTries(){
        return numIncorrectTries;
    }
    
    public void setSecretWord(StringBuffer secretWord){
        this.secretWord=secretWord;
    }
    public void setKnownSoFar(StringBuffer knownSoFar){
        this.knownSoFar=knownSoFar;
    }
    public void setAllLetters(StringBuffer allLetters){
        this.allLetters=allLetters;
    }
    public void setUsedLetters(StringBuffer usedLetters){
        this.usedLetters=usedLetters;
    }
    public void setNumIncorrectTries(int numIncorrectTries){
        this.numIncorrectTries=numIncorrectTries;
    }

    public String chooseSecretWord(){
        return "";
    }
    public void tryThis(){

    }

    /** Group Members:
     * Elif Pınar Balbal  22103625
     * Sarper Arda Bakır   21902781
     * Ercan Bahri Nazlıoğlu  21903151
     * Tolga Han Arslan  22003061
     */

    
}