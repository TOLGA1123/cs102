/*
 *This program is a class for the object of a hangman game
 * 
 * Date: 8th of February 2022
 * 
 * @authors: Efe Tuna Can, Atilla Alp Yavuz, Çağan Tuncer, Tolga Artun Koçak
 */

public class Hangman {
    //variables
    private String secretWord;
    private String allLetters;
    private StringBuffer knownSoFar;
    private StringBuffer usedLetters;
    private int incorrectTries;
    private int maxAllowedIncorrectTries = 6;

    //methods created by other groups
    public Hangman(){}

    public void chooseSecretWord(){}

    public void tryThis(){}

    //getters
    public String getAllLetters(){
        return this.allLetters;
    }
    public String getUsedLetters(){
        return this.UsedLetters;
    }
    public int getNumOfIncorrectTries(){
        return this.incorrectTries;
    }
    public int getMaxAllowedIncorrectTries(){
        return this.maxAllowedIncorrectTries;
    }
    public String getKnownSofar(){
        return this.knownSoFar;
    }
    //returns indicators for games status
    public boolean isGameOver(){
        return true;
    }
    public boolean hasLost(){
        return true;
    }







    // ziya.erkoc@bilkent.edu.tr
    



}