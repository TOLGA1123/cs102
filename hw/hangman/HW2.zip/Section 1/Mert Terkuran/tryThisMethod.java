/**
 * Try this method 
 * Mert Terkuran
 * 22101645
 * CS-102\001
 */
public class tryThisMethod {
    public String secretWord=new String();
    public int tryThis(String input){
        int count=0;
        for(int i=0;i<secretWord.length();i++){
            if(Character.toString(secretWord.charAt(i)).equalsIgnoreCase(input)) {
                count++;
            } 
        }
        return count;
    }    
}