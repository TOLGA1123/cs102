/**
 * This is a basic Hangman Game played on the terminal.
 * @author Ipek Sonmez
 * @author Ahmet Kaan Sever
 * @author Mehmet Hakan Yavuz
 * @date 08.02.2022
 */

public class Hangman{
    
    //Instance variables
    private StringBuffer secretWord = new StringBuffer();
    private StringBuffer allLetters = new StringBuffer();
    private StringBuffer usedLetters = new StringBuffer();
    private int numberOfIncorrectTries;
    private int maxAllowedIncorrectTries;
    private StringBuffer knownSoFar = new StringBuffer();

    public static void main(String[] args) {
        
    }

    //Constructor
    public Hangman(){

    }

    //Accessor Methods
    public String getAllLetters(){
        return allLetters.toString();
    }

    public String getUsedLetters(){
        return usedLetters.toString();
    }

    public int getNumOfIncorrectTries(){
        return numberOfIncorrectTries;
    }

    public int getMaxAllowedIncorrectTries(){
        return maxAllowedIncorrectTries;
    }

    //Chooses a secret word from the given list
    private void chooseSecretWord(){

    }

    //Returns the number of occurences of the letter in the secret word
    public int tryThis(Character letter){

    }

    //Returns the secret word with the correctly guessed letters displayed and other letters appearing blank
    public String getKnownSoFar(){
        return knownSoFar.toString();
    }

    //Checks whether the game is over or not
    public boolean isGameover(){
        return (hasLost() || getKnownSoFar().equals(secretWord.toString()));
    }

    //Checks whether the player has lost or not
    public boolean hasLost(){
        return (numberOfIncorrectTries > maxAllowedIncorrectTries);
    }
}